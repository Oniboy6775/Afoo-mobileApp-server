const verifyAccount = async (req, res) => {
  res.send("verify account");
};
const initialWithdrawal = async (req, res) => {
  res.send("initial Withdrawal");
};
const flw_WithdrawalWebhook = async (req, res) => {
  res.send("initial Withdrawal");
};
export { verifyAccount, initialWithdrawal, flw_WithdrawalWebhook };
